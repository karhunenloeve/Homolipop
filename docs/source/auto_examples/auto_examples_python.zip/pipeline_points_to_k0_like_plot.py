"""
Pipeline: point cloud to K0-like persistence barcodes.

This example demonstrates :func:`homolipop.pipeline_k0_like.k0_like_persistence_from_points_Fp`,
a deterministic pipeline from a finite point cloud to a barcode valued invariant over a
finite field.

Pipeline
========

Given a finite point cloud :math:`X = \\{x_0,\\dots,x_{n-1}\\} \\subset \\mathbb R^2`, the
pipeline performs the following steps.

1. Construct a proximity graph filtration :math:`(G_s)_{s=0}^{T-1}` on the fixed vertex set
   :math:`V = \\{0,\\dots,n-1\\}` using nondecreasing thresholds
   :math:`t_0 \\le \\cdots \\le t_{T-1}`.
2. Choose a deterministic orientation of each undirected edge. In this script, the option
   ``orientation="lower_to_higher"`` directs :math:`\\{i,j\\}` as :math:`i \\to j` when
   :math:`i < j`.
3. For each step :math:`s`, let :math:`E_s` be the resulting directed edge set and define the
   finite field linear K0-like invariant

   .. math::

      K0_{\\mathrm{like}}(s)
      =
      \\mathbb F_p^{V} \\big/ \\langle e_v - e_u : (u \\to v) \\in E_s \\rangle.

4. Compute persistence for this assignment as a persistence module over :math:`\\mathbb F_p`
   and output its barcode representation.

Mathematical meaning
====================

Define the two term chain complex over :math:`\\mathbb F_p`

.. math::

   C_1(s) = \\mathbb F_p^{E_s}
   \\xrightarrow{\\partial_s}
   C_0(s) = \\mathbb F_p^{V},
   \\qquad
   \\partial_s(e_{u \\to v}) = e_v - e_u.

Then

.. math::

   K0_{\\mathrm{like}}(s) \\cong C_0(s) / \\operatorname{im}(\\partial_s) \\cong H_0(C_\\bullet(s)).

Thus the invariant is a canonical finite field vector space quotient and is functorial for
edge inclusions via the identity map on :math:`C_0`.

Toeplitz quotient direction
===========================

The phrase Toeplitz quotient direction refers to the contravariant direction of the natural
quotient maps in the Toeplitz graph algebra model. Computationally, this is represented by
reversing the filtration direction when extracting barcodes.

Reproducibility
===============

If ``deterministic_order=True``, the pipeline applies a deterministic vertex relabeling that
depends only on the point coordinates and breaks ties by the original index. This changes
only labels, not the filtered graph up to isomorphism.

All randomness in this file is controlled by NumPy's ``default_rng`` with a fixed seed.
"""

from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np

from homolipop.pipeline_k0_like import k0_like_persistence_from_points_Fp
from homolipop.plotting import plot_barcodes


def main() -> None:
    """
    Compute and plot K0-like persistence barcodes for random planar points.

    The script samples points in the unit square, computes the K0-like persistence barcode
    over :math:`\\mathbb F_2`, and displays the resulting barcode plot.
    """
    rng = np.random.default_rng(0)
    points = rng.random((80, 2))

    result = k0_like_persistence_from_points_Fp(
        points,
        p=2,
        n_steps=40,
        deterministic_order=True,
        orientation="lower_to_higher",
        include_both_directions=False,
    )

    fig = plot_barcodes(
        result.k0_like.k0_like,
        title="K0-like persistence over F_2 in Toeplitz quotient direction",
    )
    plt.show()
    plt.close(fig)


if __name__ == "__main__":
    main()